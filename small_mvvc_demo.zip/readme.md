## How to use

### look in browser
```
npm insatll
npm start

```

### unit test
```
npm run test
```