export class HeroComponent {
    constructor() {
        this.hero_name = 'Ultraman';
        this.age = 17;
    }
}


