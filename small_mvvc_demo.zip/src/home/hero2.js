export class HeroComponent2 {
    constructor() {
        this.hero_name = 'SuperMan';
        this.age = 28;
    }
}


